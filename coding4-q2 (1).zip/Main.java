/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    static void merge(int[]a,int[]b )
    {
        int[] res = new int[a.length+b.length];
        int i=0;
        int j=0; 
        int k=0;
        while(i<a.length && j<b.length)
        {
            if(a[i]<b[j])
            {
                res[k]=a[i];
                i++;
                k++;
            }
            else
            {
                res[k]=b[j];
                j++;
                k++;
            }
        }
        while(i<a.length)
        {
            res[k]=a[i];
            i++;
            k++;
            
        }
        while(j<b.length)
        {
            res[k]=b[j];
            j++;
            k++;
        }
        for(int l=0;i<res.length;i++)
        {
            System.out.print(res[l]+" ");
        }
        System.out.println();
        
    }
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int m =sc.nextInt();
		int a[]=new int[n];
		int b[]=new int[n];
		for(int i=0;i<n;i++)
		{
		    a[i]=sc.nextInt();
		}
		for(int i=0;i<m;i++)
		{
		    b[i]=sc.nextInt();
		}
/*	int[] resultant=merge(a,b);
	for(int i=0;i<resultant.length;i++)
	{
	    System.out.print(resultant[i]+ " ");
	}
	System.out.println();*/
	}
}
